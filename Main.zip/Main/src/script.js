const video = document.getElementById('video')
Promise.all([
  faceapi.nets.tinyFaceDetector.loadFromUri('/Main/src/models'),
  faceapi.nets.faceLandmark68Net.loadFromUri('/Main/src/models'),
  faceapi.nets.faceRecognitionNet.loadFromUri('/Main/src/models'),
  faceapi.nets.faceExpressionNet.loadFromUri('/Main/src/models')
]).then(video.onload = function() {
  const canvas = faceapi.createCanvasFromMedia(video)
  const crop_canvas = document.getElementById('mycanvas');
  const context = crop_canvas.getContext('2d');
  document.body.append(canvas)
  const displaySize = { width: video.width, height: video.height }
  faceapi.matchDimensions(canvas, displaySize)
  setInterval(async () => {
    const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions())
    const resizedDetections = faceapi.resizeResults(detections, displaySize)
    canvas.getContext('2d')
    faceapi.draw.drawDetections(canvas, resizedDetections)
    // context.drawImage(video, 1200, 200, 200, 200, 250,150, 200, 200);
    console.log(detections)
    context.fillStyle = "red";
    context.fillRect(detections[0]._box._x,detections[0]._box._y,25,25); 
  }, 100)
})
